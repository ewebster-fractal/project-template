#!/bin/bash

# build the docker file
# https://medium.com/@chadlagore/conda-environments-with-docker-82cdc9d25754
docker build -f dockerfile .